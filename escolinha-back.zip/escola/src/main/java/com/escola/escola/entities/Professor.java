package com.escola.escola.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="professor")
@Entity
public class Professor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idprofessor")

    private Integer IdProfessor;

    @Column(name = "nome", length = 150, nullable = false)
    private String nome;

    @Column(name = "endereco", length = 150, nullable = false)
    private String endereco;

    public Professor() {
        // TODO Auto-generated constructor stub
    }

    public Integer getIdProfessor() {
        return IdProfessor;
    }

    public void setIdProfessor(Integer idProfessor) {
        IdProfessor = idProfessor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "Professor [IdProfessor=" + IdProfessor + ", nome=" + nome + ", endereco=" + endereco + "]";
    }

    public Professor(Integer idProfessor, String nome, String endereco) {
        super();
        IdProfessor = idProfessor;
        this.nome = nome;
        this.endereco = endereco;
    }


}
