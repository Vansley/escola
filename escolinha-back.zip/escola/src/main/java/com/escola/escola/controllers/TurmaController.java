package com.escola.escola.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.escola.escola.entities.Aluno;
import com.escola.escola.entities.Turma;
import com.escola.escola.repositories.IAlunoRepository;
import com.escola.escola.repositories.ITurmaRepository;
import com.escola.escola.requests.TurmaPostRequest;
import com.escola.escola.requests.TurmaPutRequest;
import com.escola.escola.responses.TurmaAlunosGetResponse;
import com.escola.escola.responses.TurmaGetResponse;

import io.swagger.annotations.ApiOperation;


@Controller
@RestController
@Transactional
public class TurmaController {
	@Autowired
	private ITurmaRepository turmaRepository;
	@Autowired
	private IAlunoRepository alunoRepository;
	
	private static final String ENDPOINT= "api/turmas";

	@RequestMapping(value=ENDPOINT, method=RequestMethod.POST)
	@ApiOperation("Serviço para cadastro de turmas")
	@CrossOrigin
	public ResponseEntity<String>post(@RequestBody TurmaPostRequest request){
		try {
			Turma turma= new Turma();
			turma.setSemestre(request.getSemestre());
			turma.setAno(request.getAno());
		

			turmaRepository.save(turma);

			return ResponseEntity.status(HttpStatus.OK).body("Turma cadastrada com sucesso.");

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro:"+e.getMessage());
		}
	}

	@RequestMapping(value=ENDPOINT, method=RequestMethod.PUT)
	@ApiOperation("Serviço para edição de turma")
	@CrossOrigin
	public ResponseEntity<String>put(@RequestBody TurmaPutRequest request){
		try {
			
			Optional<Turma> item= turmaRepository.findById(request.getIdTurma());
			if(item.isEmpty()) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Turma não encontrado");
			}else {
				Turma turma= new Turma();
				turma.setSemestre(request.getSemestre());
				turma.setAno(request.getAno());
	
				turmaRepository.save(turma);
				return ResponseEntity.status(HttpStatus.OK).body("Turma atualizada com sucesso");

			}

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro:"+e.getMessage());
		}
	}
	
	
	@RequestMapping(value=ENDPOINT, method=RequestMethod.GET)
	@ApiOperation("Serviço para consulta de turma")
	@CrossOrigin
	public ResponseEntity<List<TurmaGetResponse>>get() {
		List<TurmaGetResponse> response= new ArrayList<TurmaGetResponse>();
		for(Turma turma: turmaRepository.findAll()) {
			TurmaGetResponse item= new TurmaGetResponse();
			item.setIdTurma(turma.getIdTurma());
			item.setSemestre(turma.getSemestre());
			item.setAno(turma.getAno());
		
			response.add(item);
		}
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	@RequestMapping(value=ENDPOINT + "/{idTurma}", method=RequestMethod.GET)
	@ApiOperation("Serviço para consulta de turma")
	@CrossOrigin
	public ResponseEntity<TurmaAlunosGetResponse>getById(@PathVariable("idTurma") Integer idTurma) {
		Optional<Turma> item= turmaRepository.findById(idTurma);
		if(item.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}else {
			TurmaAlunosGetResponse response= new TurmaAlunosGetResponse();
			Turma turma= item.get();		
			response.setSemestre(idTurma);
			List<Aluno> alunos = alunoRepository.findByIdTurma(turma.getIdTurma());
			for(Aluno aluno:alunos) {
				response.getNomesAlunos().add(aluno.getNome());
			}
			return ResponseEntity.status(HttpStatus.OK).body(response);
			
		}
	}
	
}

