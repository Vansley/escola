package com.escola.escola.requests;

public class TurmaPostRequest {
	
	private Integer idTurma;
    private String semestre;
    private String ano;
   
    public TurmaPostRequest() {
		// TODO Auto-generated constructor stub
	}

	public TurmaPostRequest(Integer idTurma, String semestre, String ano) {
		super();
		this.idTurma = idTurma;
		this.semestre = semestre;
		this.ano = ano;
	}

	public Integer getIdTurma() {
		return idTurma;
	}

	public void setIdTurma(Integer idTurma) {
		this.idTurma = idTurma;
	}

	public String getSemestre() {
		return semestre;
	}

	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	@Override
	public String toString() {
		return "TurmaPostRequest [idTurma=" + idTurma + ", semestre=" + semestre + ", ano=" + ano + "]";
	}
    
}