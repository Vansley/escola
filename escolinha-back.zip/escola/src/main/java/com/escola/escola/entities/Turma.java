package com.escola.escola.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="turma")
public class Turma {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idturma")

    private Integer IdTurma;

    @Column(name = "semestre", length = 150, nullable = false)
    private String semestre;

    @Column(name = "ano", length = 150, nullable = false)
    private String ano;

    
    public Turma() {
		// TODO Auto-generated constructor stub
	}
    
    
	public Turma(Integer idTurma, String semestre, String ano) {
		super();
		IdTurma = idTurma;
		this.semestre = semestre;
		this.ano = ano;
	}


	public Integer getIdTurma() {
		return IdTurma;
	}

	public void setIdTurma(Integer idTurma) {
		IdTurma = idTurma;
	}

	public String getSemestre() {
		return semestre;
	}

	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}


	@Override
	public String toString() {
		return "Turma [IdTurma=" + IdTurma + ", semestre=" + semestre + ", ano=" + ano + "]";
	}


   
}
