package com.escola.escola.repositories;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.escola.escola.entities.Aluno;

@Repository
public interface IAlunoRepository extends JpaRepository<Aluno, Integer> {
	@Query(value = "Select * from aluno where id_turma=?1", nativeQuery = true)
	List<Aluno> findByIdTurma(Integer idTurma);

}
