package com.escola.escola.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="aluno")
public class Aluno {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idaluno")

    private Integer IdAluno;

    @Column(name = "nome", length = 150, nullable = false)
    private String nome;

    @Column(name = "endereco", length = 150, nullable = false)
    private String endereco;
    
    @ManyToOne
    @JoinColumn(name="idTurma")
    private Turma turma;

    public Aluno() {
    	super();
    }

	public Aluno(Integer idAluno, String nome, String endereco, Turma turma) {
		super();
		IdAluno = idAluno;
		this.nome = nome;
		this.endereco = endereco;
		this.turma = turma;
	}

	public Integer getIdAluno() {
		return IdAluno;
	}

	public void setIdAluno(Integer idAluno) {
		IdAluno = idAluno;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public Turma getTurma() {
		return turma;
	}

	public void setTurma(Turma turma) {
		this.turma = turma;
	}

}