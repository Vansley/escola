/*package com.escola.escola.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import com.escola.escola.security.JwtSecurity;
@Configuration
@EnableWebSecurity
public class JwtConfiguration extends WebSecurityConfigurerAdapter {
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.csrf().disable()
				.addFilterAfter(new JwtSecurity(), 
				UsernamePasswordAuthenticationFilter.class)
				.authorizeRequests()
				.antMatchers(HttpMethod.POST, "/api/account").permitAll()
				.antMatchers(HttpMethod.POST, "/api/login").permitAll()
				
				.antMatchers(HttpMethod.POST, "/api/alunos").permitAll()
				.antMatchers(HttpMethod.GET, "/api/alunos").permitAll()
				.antMatchers(HttpMethod.PUT, "/api/alunos").permitAll()
				.antMatchers(HttpMethod.DELETE, "/api/alunos").permitAll()
				
				.antMatchers(HttpMethod.POST, "/api/professores").permitAll()
				.antMatchers(HttpMethod.GET, "/api/professores").permitAll()
				.antMatchers(HttpMethod.PUT, "/api/professores").permitAll()
				.antMatchers(HttpMethod.DELETE, "/api/professores").permitAll()
				
				.antMatchers(HttpMethod.POST, "/api/turmas").permitAll()
				.antMatchers(HttpMethod.GET, "/api/turmas").permitAll()
				.antMatchers(HttpMethod.PUT, "/api/turmas").permitAll()
				.antMatchers(HttpMethod.DELETE, "/api/turmas").permitAll()
				
				.antMatchers(HttpMethod.POST, "/api/cursos").permitAll()
				.antMatchers(HttpMethod.GET, "/api/cursos").permitAll()
				.antMatchers(HttpMethod.PUT, "/api/cursos").permitAll()
				.antMatchers(HttpMethod.DELETE, "/api/cursos").permitAll()
				
				
				.antMatchers(HttpMethod.OPTIONS, "/**").permitAll() 
				.anyRequest()
				.authenticated();
	}

	// configuração para liberar a documentação do SWAGGER
	private static final String[] SWAGGER = {
			"/v2/api-docs", "/swagger-resources", "/swagger-resources/**", "/configuration/ui",
			"/configuration/security", "/swagger-ui.html", "/webjars/**",
			"/v3/api-docs/*", "/swagger-ui/*"
	};

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(SWAGGER);
	}
}
*/