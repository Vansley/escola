package com.escola.escola.responses;

public class TurmaGetResponse {
	
	private Integer idTurma;
    private String semestre;
    private String ano;
    
   public TurmaGetResponse() {
	// TODO Auto-generated constructor stub
}

public TurmaGetResponse(Integer idTurma, String semestre, String ano) {
	super();
	this.idTurma = idTurma;
	this.semestre = semestre;
	this.ano = ano;
}

public Integer getIdTurma() {
	return idTurma;
}

public void setIdTurma(Integer idTurma) {
	this.idTurma = idTurma;
}

public String getSemestre() {
	return semestre;
}

public void setSemestre(String semestre) {
	this.semestre = semestre;
}

public String getAno() {
	return ano;
}

public void setAno(String ano) {
	this.ano = ano;
}

@Override
public String toString() {
	return "TurmaGetResponse [idTurma=" + idTurma + ", semestre=" + semestre + ", ano=" + ano + "]";
}
   
}