package com.escola.escola.repositories;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;

import com.escola.escola.entities.Professor;

@SpringBootApplication
public interface IProfessorRepository extends JpaRepository<Professor, Integer>{


}
